# LG TV Controller App v3.0

## What's new in v3
- FTP server requires **no password** — connect as `anonymous` or `lguser` with no password
- Guest access fully enabled

## How it works

- **CONNECT** – Enter TV IP, SSH user & password (saveable) → SSH in → Creates `/sdcard/lgtvscreen/` if not already there → Starts FTP server on phone (port 9999, no password) → Auto-saves phone IP to `/media/developer/phone_ip.txt` on TV
- **DISCONNECT** – Stops FTP server + closes SSH
- **FHD** – Runs `/media/developer/screen.sh` on TV
- **4K** – Runs `/media/developer/ftp_screenshot.sh` on TV

## FTP Server (on your phone)

| Setting | Value |
|---------|-------|
| Port | 9999 |
| Username | `anonymous` or `lguser` |
| Password | *(none)* |
| Folder | `/sdcard/lgtvscreen/` |

## How to Build

1. Open **Android Studio** → File → Open → select `LGTVController` folder
2. Wait for Gradle sync
3. Build → Build APK(s)
4. APK at: `app/build/outputs/apk/debug/app-debug.apk`

### Android 11+ extra step
Settings → Privacy → Permission manager → Files and media → LG TV Control → **Allow management of all files**
