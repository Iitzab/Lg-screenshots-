package com.home.lgtvcontroller;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.textfield.TextInputEditText;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.ftplet.Authority;
import org.apache.ftpserver.ftplet.FtpException;
import org.apache.ftpserver.listener.ListenerFactory;
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory;
import org.apache.ftpserver.usermanager.impl.BaseUser;
import org.apache.ftpserver.usermanager.impl.WritePermission;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS         = "lgtvprefs";
    private static final String KEY_IP        = "tv_ip";
    private static final String KEY_USER      = "tv_user";
    private static final String KEY_PASS      = "tv_pass";
    private static final String KEY_REMEMBER  = "remember";
    private static final String PHONE_IP_FILE = "/media/developer/phone_ip.txt";
    private static final String FHD_SCRIPT    = "/media/developer/screen.sh";
    private static final String K4_SCRIPT     = "/media/developer/ftp_screenshot.sh";
    private static final int    FTP_PORT      = 9999;

    private TextInputEditText etTvIp, etUsername, etPassword;
    private CheckBox cbRemember;
    private Button btnConnect, btnDisconnect, btnFHD, btnFourK;
    private TextView tvLog, tvStatus, tvFtpStatus;
    private ScrollView scrollLog;

    private Session sshSession;
    private FtpServer ftpServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etTvIp        = findViewById(R.id.etTvIp);
        etUsername    = findViewById(R.id.etUsername);
        etPassword    = findViewById(R.id.etPassword);
        cbRemember    = findViewById(R.id.cbRemember);
        btnConnect    = findViewById(R.id.btnConnect);
        btnDisconnect = findViewById(R.id.btnDisconnect);
        btnFHD        = findViewById(R.id.btnFHD);
        btnFourK      = findViewById(R.id.btnFourK);
        tvLog         = findViewById(R.id.tvLog);
        tvStatus      = findViewById(R.id.tvStatus);
        tvFtpStatus   = findViewById(R.id.tvFtpStatus);
        scrollLog     = findViewById(R.id.scrollLog);

        loadSavedPrefs();
        requestPermissions();

        btnConnect.setOnClickListener(v -> doConnect());
        btnDisconnect.setOnClickListener(v -> doDisconnect());
        btnFHD.setOnClickListener(v -> runScript("FHD", FHD_SCRIPT));
        btnFourK.setOnClickListener(v -> runScript("4K", K4_SCRIPT));
    }

    // ── CONNECT ──────────────────────────────────────────────────
    private void doConnect() {
        String host = getText(etTvIp);
        String user = getText(etUsername);
        String pass = getText(etPassword);

        if (host.isEmpty() || user.isEmpty() || pass.isEmpty()) {
            setStatus("⚠ Fill in TV IP, username and password", false);
            return;
        }

        if (cbRemember.isChecked()) savePrefs(host, user, pass);

        setAllButtons(false, false, false, false);
        setStatus("⏳ Connecting…", false);

        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... v) {
                try {
                    // 1. Prepare local FTP folder on phone (skip if already exists)
                    File sdcard = Environment.getExternalStorageDirectory();
                    File folder = new File(sdcard, "lgtvscreen");
                    if (!folder.exists()) {
                        folder.mkdirs();
                        publishProgress("📁 Created folder: " + folder.getAbsolutePath());
                    } else {
                        publishProgress("📁 Folder exists: " + folder.getAbsolutePath());
                    }

                    // 2. Get phone IP
                    String phoneIp = getPhoneIp();
                    if (phoneIp == null) return "❌ Could not detect phone IP (is Wi-Fi on?)";
                    publishProgress("📱 Phone IP: " + phoneIp);

                    // 3. SSH connect
                    publishProgress("🔌 SSH connecting to " + host + "…");
                    JSch jsch = new JSch();
                    sshSession = jsch.getSession(user, host, 22);
                    sshSession.setPassword(pass);
                    Properties config = new Properties();
                    config.put("StrictHostKeyChecking", "no");
                    sshSession.setConfig(config);
                    sshSession.setTimeout(10000);
                    sshSession.connect();
                    publishProgress("✅ SSH connected");

                    // 4. Write phone IP to TV
                    runCommand(sshSession, "echo '" + phoneIp + "' > " + PHONE_IP_FILE);
                    publishProgress("📝 Phone IP saved → " + PHONE_IP_FILE);

                    // 5. Start FTP server (no password, guest/anonymous allowed)
                    publishProgress("📡 Starting FTP server on port " + FTP_PORT + "…");
                    startFtpServer(folder.getAbsolutePath());
                    publishProgress("✅ FTP ready  ftp://" + phoneIp + ":" + FTP_PORT + "  (no password)");

                    return "CONNECTED:" + phoneIp;

                } catch (Exception e) {
                    if (sshSession != null && sshSession.isConnected()) sshSession.disconnect();
                    return "❌ " + e.getMessage();
                }
            }

            @Override
            protected void onProgressUpdate(String... values) { appendLog(values[0]); }

            @Override
            protected void onPostExecute(String result) {
                if (result.startsWith("CONNECTED:")) {
                    String phoneIp = result.split(":")[1];
                    setStatus("● Connected", true);
                    tvFtpStatus.setText("FTP: ftp://" + phoneIp + ":" + FTP_PORT + "  (no password / guest ok)");
                    setAllButtons(false, true, true, true);
                } else {
                    appendLog(result);
                    setStatus("● Disconnected", false);
                    setAllButtons(true, false, false, false);
                }
            }
        }.execute();
    }

    // ── DISCONNECT ───────────────────────────────────────────────
    private void doDisconnect() {
        setAllButtons(false, false, false, false);
        setStatus("⏳ Disconnecting…", false);

        new AsyncTask<Void, String, Void>() {
            @Override
            protected Void doInBackground(Void... v) {
                try {
                    if (ftpServer != null && !ftpServer.isStopped()) {
                        ftpServer.stop();
                        publishProgress("🛑 FTP server stopped");
                    }
                } catch (Exception e) {
                    publishProgress("⚠ FTP stop: " + e.getMessage());
                }
                try {
                    if (sshSession != null && sshSession.isConnected()) {
                        sshSession.disconnect();
                        publishProgress("🛑 SSH disconnected");
                    }
                } catch (Exception e) {
                    publishProgress("⚠ SSH disconnect: " + e.getMessage());
                }
                return null;
            }

            @Override
            protected void onProgressUpdate(String... values) { appendLog(values[0]); }

            @Override
            protected void onPostExecute(Void v) {
                setStatus("● Disconnected", false);
                tvFtpStatus.setText("");
                setAllButtons(true, false, false, false);
            }
        }.execute();
    }

    // ── RUN SCRIPT ───────────────────────────────────────────────
    private void runScript(String label, String scriptPath) {
        if (sshSession == null || !sshSession.isConnected()) {
            setStatus("⚠ Not connected", false);
            return;
        }
        setAllButtons(false, false, false, false);
        appendLog("\n▶ " + label);

        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... v) {
                try {
                    String out = runCommand(sshSession, "sh " + scriptPath);
                    if (!out.isEmpty()) publishProgress(out);
                    return "✅ " + label + " done";
                } catch (Exception e) {
                    return "❌ " + e.getMessage();
                }
            }

            @Override
            protected void onProgressUpdate(String... values) { appendLog(values[0]); }

            @Override
            protected void onPostExecute(String result) {
                appendLog(result);
                setStatus("● Connected", true);
                setAllButtons(false, true, true, true);
            }
        }.execute();
    }

    // ── FTP SERVER (no password, anonymous + named guest) ────────
    private void startFtpServer(String folder) throws FtpException {
        FtpServerFactory serverFactory = new FtpServerFactory();

        ListenerFactory listenerFactory = new ListenerFactory();
        listenerFactory.setPort(FTP_PORT);
        serverFactory.addListener("default", listenerFactory.createListener());

        PropertiesUserManagerFactory userManagerFactory = new PropertiesUserManagerFactory();
        org.apache.ftpserver.usermanager.UserManager userManager = userManagerFactory.createUserManager();

        List<Authority> fullAccess = new ArrayList<>();
        fullAccess.add(new WritePermission());

        // Named user with no password
        BaseUser user = new BaseUser();
        user.setName("lguser");
        user.setPassword("");
        user.setHomeDirectory(folder);
        user.setEnabled(true);
        user.setMaxIdleTime(0);
        user.setAuthorities(fullAccess);
        userManager.save(user);

        // Anonymous / guest — no password
        BaseUser anonymous = new BaseUser();
        anonymous.setName("anonymous");
        anonymous.setPassword("");
        anonymous.setHomeDirectory(folder);
        anonymous.setEnabled(true);
        anonymous.setMaxIdleTime(0);
        anonymous.setAuthorities(fullAccess);
        userManager.save(anonymous);

        serverFactory.setUserManager(userManager);
        ftpServer = serverFactory.createServer();
        ftpServer.start();
    }

    // ── SSH HELPER ───────────────────────────────────────────────
    private String runCommand(Session session, String cmd) throws Exception {
        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        channel.setCommand(cmd);
        channel.setErrStream(System.err, true);
        BufferedReader reader = new BufferedReader(new InputStreamReader(channel.getInputStream()));
        channel.connect();
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line).append("\n");
        channel.disconnect();
        return sb.toString().trim();
    }

    // ── GET PHONE IP ─────────────────────────────────────────────
    private String getPhoneIp() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : interfaces) {
                if (!ni.getName().startsWith("wlan") && !ni.getName().startsWith("eth")) continue;
                List<InetAddress> addrs = Collections.list(ni.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress() && addr.getHostAddress().contains("."))
                        return addr.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        // Fallback via WifiManager
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            int ip = wm.getConnectionInfo().getIpAddress();
            return (ip & 0xFF) + "." + ((ip >> 8) & 0xFF) + "." + ((ip >> 16) & 0xFF) + "." + ((ip >> 24) & 0xFF);
        } catch (Exception ignored) {}
        return null;
    }

    // ── PREFS ─────────────────────────────────────────────────────
    private void savePrefs(String ip, String user, String pass) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_IP, ip)
            .putString(KEY_USER, user)
            .putString(KEY_PASS, pass)
            .putBoolean(KEY_REMEMBER, true)
            .apply();
    }

    private void loadSavedPrefs() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (p.getBoolean(KEY_REMEMBER, false)) {
            etTvIp.setText(p.getString(KEY_IP, ""));
            etUsername.setText(p.getString(KEY_USER, ""));
            etPassword.setText(p.getString(KEY_PASS, ""));
            cbRemember.setChecked(true);
        }
    }

    // ── UI HELPERS ────────────────────────────────────────────────
    private void setStatus(String msg, boolean connected) {
        runOnUiThread(() -> {
            tvStatus.setText(msg);
            tvStatus.setTextColor(connected ? 0xFF00E676 : 0xFFEF5350);
        });
    }

    private void appendLog(String line) {
        runOnUiThread(() -> {
            tvLog.append(line + "\n");
            scrollLog.post(() -> scrollLog.fullScroll(View.FOCUS_DOWN));
        });
    }

    private void setAllButtons(boolean connect, boolean disconnect, boolean fhd, boolean fourk) {
        runOnUiThread(() -> {
            btnConnect.setEnabled(connect);
            btnDisconnect.setEnabled(disconnect);
            btnFHD.setEnabled(fhd);
            btnFourK.setEnabled(fourk);
        });
    }

    private String getText(TextInputEditText et) {
        return et.getText() != null ? et.getText().toString().trim() : "";
    }

    // ── PERMISSIONS ───────────────────────────────────────────────
    private void requestPermissions() {
        String[] perms = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        List<String> needed = new ArrayList<>();
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                needed.add(p);
        }
        if (!needed.isEmpty())
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), 1);
    }
}
